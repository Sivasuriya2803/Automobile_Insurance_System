package com.example.demo.model;

public enum ProposalStatus {
    PROPOSAL_SUBMITTED,
    QUOTE_GENERATED,
    ACTIVE,
    EXPIRED
}
