package com.example.demo.model;

public enum VehicleType {
	 car,
	    motorcycle,
	    campervan

}
