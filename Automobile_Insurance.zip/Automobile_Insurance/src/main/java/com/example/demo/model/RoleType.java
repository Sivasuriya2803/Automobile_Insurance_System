package com.example.demo.model;

public enum RoleType {
	User,
    Officer,
    Admin,
    CustomerService,
    UnderWriter

}
