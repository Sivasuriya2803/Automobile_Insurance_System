package com.example.demo.dto;

import lombok.Data;

@Data
public class ProposalRequestDTO {
	 public int userId;
	    public int vehicleId;
	    public double quoteAmount;
	    public double finalPremium;

}
