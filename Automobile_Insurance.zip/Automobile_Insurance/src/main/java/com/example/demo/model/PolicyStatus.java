package com.example.demo.model;

public enum PolicyStatus {
	PROPOSAL_SUBMITTED,
    QUOTE_GENERATED,
    ACTIVE,
    EXPIRED

}
