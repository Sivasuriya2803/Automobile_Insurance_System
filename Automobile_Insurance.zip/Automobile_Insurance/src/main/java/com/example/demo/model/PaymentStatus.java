package com.example.demo.model;

public enum PaymentStatus {
	success,
	failed,
	pending
	

}
